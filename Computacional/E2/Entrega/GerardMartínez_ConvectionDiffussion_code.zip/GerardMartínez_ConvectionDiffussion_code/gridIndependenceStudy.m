%% Grid Independence Study
% Assesses convergence of the HDS scheme on progressively refined meshes
% Computes mean absolute error against analytical Smith-Hutton reference data

clearvars; close all;

fprintf('=== Grid Independence Study (HDS) ===\n\n');

mesh_resolutions = linspace(25, 500, 20);
mae_values = zeros(length(mesh_resolutions), 3);
num_cells = zeros(length(mesh_resolutions), 1);

analytical_data_x = [0.000, 0.100, 0.200, 0.300, 0.400, 0.500, 0.600, 0.700, 0.800, 0.900, 1.000]';
analytical_data_p = [1.989, 1.402, 1.146, 0.946, 0.775, 0.621, 0.480, 0.349, 0.227, 0.111, 0.000;
                     2.00,  1.999, 1.9997, 1.985, 1.841, 0.951, 0.154, 0.001, 0.000, 0.000, 0.000;
                     2.000, 2.000, 2.000, 1.999, 1.964, 1.000, 0.036, 0.001, 0.000, 0.000, 0.000]';
mean_anal = mean(analytical_data_p);

for k = 1:length(mesh_resolutions)
    N = mesh_resolutions(k);
    fprintf('Running simulation with N = %d cells...\n', N);
    
    diag = false;
    case_study = "HDS";
    
    [Geometry, Fluid, Numerical, BoundaryConditions] = setupSimulation(diag);
    Numerical.N = N;
    Numerical.M = round(Geometry.H / Geometry.L * Numerical.N);
    
    num_cells(k) = Numerical.N * Numerical.M;
    
    [nod_x, nod_y, center_x, center_y, sx_w, sx_e, sx_p, sy_s, sy_n, sy_p] = generateMesh(Geometry, Numerical);
    
    A_x = Geometry.L / Numerical.N;
    A_y = Geometry.H / Numerical.M;
    
    x = nod_x - Geometry.H;
    [surf_x, surf_y] = meshgrid(x, fliplr(nod_y));
    surf_x = surf_x';
    surf_y = fliplr(surf_y');
    
    [v_x, v_y] = computeVelocityField(surf_x, surf_y, Fluid, diag);
    
    phi_def = zeros(Numerical.N+2, Numerical.M+2, length(Fluid.gamma));
    
    for l = 1:length(Fluid.gamma)
        phi_in = ones(Numerical.N+2, Numerical.M+2) * BoundaryConditions.phi_inlet;
        phi_prev = phi_in;
        
        [a_n, a_s, a_e, a_w, a_p, a_p_base, b_p] = computeCoefficients(v_x, v_y, Numerical, Fluid, ...
                                                                      sx_w, sx_e, sx_p, sy_s, sy_n, sy_p, ...
                                                                      Fluid.gamma(l), case_study, A_x, A_y);
        
        [a_n, a_s, a_e, a_w, a_p, b_p] = applyBoundaryConditions(a_n, a_s, a_e, a_w, a_p, a_p_base, b_p, ...
                                                                  surf_x, Numerical, diag, BoundaryConditions);
        
        [phi, ~, ~] = solveSystem(a_n, a_s, a_e, a_w, a_p, a_p_base, b_p, ...
                                   phi_in, phi_prev, Numerical);
        
        phi_def(:, :, l) = phi;
    end
    
    for l = 1:length(Fluid.gamma)
        phi_n = zeros(length(analytical_data_x), 1);
        int_phi = interp1(nod_x - Geometry.H, phi_def(:, 1, l), analytical_data_x, 'linear', 'extrap');
        phi_n = int_phi(:);
        
        mae_values(k, l) = mean(abs(phi_n - analytical_data_p(:, l)))/mean_anal(l)*100;
    end
    
    fprintf('  MAE (rho/Gamma=10): %.6e\n', mae_values(k, 1));
    fprintf('  MAE (rho/Gamma=1e3): %.6e\n', mae_values(k, 2));
    fprintf('  MAE (rho/Gamma=1e6): %.6e\n\n', mae_values(k, 3));
end
%% PLOT

figure('Name', 'Grid Independence Study', 'NumberTitle', 'off');
hold on;
plot(mesh_resolutions, mae_values(:, 1), '-o', 'LineWidth', 2, 'MarkerSize', 8, 'DisplayName', '$\rho/\Gamma = 10$');
plot(mesh_resolutions, mae_values(:, 2), '-s', 'LineWidth', 2, 'MarkerSize', 8, 'DisplayName', '$\rho/\Gamma = 10^3$');
plot(mesh_resolutions, mae_values(:, 3), '-^', 'LineWidth', 2, 'MarkerSize', 8, 'DisplayName', '$\rho/\Gamma = 10^6$');
hold off;

xlabel('Total Grid Cells (N $\times$ M)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Mean Absolute Error (%)', 'Interpreter', 'latex', 'FontSize', 12);
title('Grid Independence Study - HDS Scheme', 'FontSize', 14);
legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 11);
grid on;
ax = gca;
ax.GridAlpha = 0.3;

exportgraphics(gca, 'figures/gridIndependenceStudy.png', 'Resolution', 300, 'ContentType', 'image', 'BackgroundColor', 'white');

fprintf('=== Grid Independence Study Completed ===\n');
fprintf('Results saved to figures/gridIndependenceStudy.png\n');
