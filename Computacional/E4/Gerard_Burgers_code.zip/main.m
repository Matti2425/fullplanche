clearvars; close all; clc;
fprintf("Initializing Burgers simulation...\n");
params = setupSimulation();
fprintf("Loaded parameters: Re=%d, cases=%d\n", params.Re, numel(params.cases));

% Try to load cached results
fprintf("Checking for cached results...\n");
[results, cached_params, found] = loadCachedResults(params);

if found
    fprintf("Using cached results (computed previously).\n");
    % Use cached params in case they differ slightly
    params = cached_params;
else
    fprintf("No cache found. Running simulations...\n");
    results = runSimulation(params);
    fprintf("Simulation runs completed. Caching results...\n");
    cacheResults(results, params);
end

fprintf("Generating figures...\n");
plotEnergySpectrum(results, params);
fprintf("All outputs generated.\n");
